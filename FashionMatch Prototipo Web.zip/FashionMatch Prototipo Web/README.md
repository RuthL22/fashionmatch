
  # FashionMatch Prototipo Web

  This is a code bundle for FashionMatch Prototipo Web. The original project is available at https://www.figma.com/design/b07ASm4uxQ81zM0625fLnj/FashionMatch-Prototipo-Web.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  