from sqlalchemy.orm import Session
from typing import Optional, List

from . import models, schemas


def get_or_create_user_by_email(db: Session, email: str, name: Optional[str] = None):
    user = db.query(models.User).filter(models.User.email == email).first()
    if user:
        return user
    user = models.User(email=email, name=name)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_recommendation(
    db: Session, payload: schemas.RecommendationCreate, suggested_outfit: str
) -> models.Recommendation:
    user = None
    if payload.user_email:
        user = get_or_create_user_by_email(db, payload.user_email)

    db_rec = models.Recommendation(
        user_id=user.id if user else None,
        description=payload.description,
        image_url=payload.image_url,
        suggested_outfit=suggested_outfit,
    )
    db.add(db_rec)
    db.commit()
    db.refresh(db_rec)
    return db_rec


def get_recommendations(db: Session, skip: int = 0, limit: int = 20) -> List[models.Recommendation]:
    return (
        db.query(models.Recommendation)
        .order_by(models.Recommendation.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )
