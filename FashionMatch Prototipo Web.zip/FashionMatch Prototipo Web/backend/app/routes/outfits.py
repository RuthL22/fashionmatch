from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List

from ..database import get_db
from .. import schemas, crud

router = APIRouter(
    prefix="/api/outfits",
    tags=["outfits"],
)


@router.post("/recommend", response_model=schemas.Recommendation)
def recommend_outfit(
    payload: schemas.RecommendationCreate,
    db: Session = Depends(get_db),
):
    base = payload.description.lower()

    if "casual" in base:
        suggested = "Jeans mom fit claros, remera básica blanca, zapatillas blancas y blazer beige."
    elif "formal" in base:
        suggested = "Pantalón de vestir crema, blusa satinada marfil, stilettos nude y blazer estructurado."
    elif "noche" in base or "fiesta" in base:
        suggested = "Vestido midi negro, sandalias de tiras, clutch metálico y aros protagónicos."
    else:
        suggested = "Pantalón neutro, blusa en tu paleta de color ideal y accesorios dorados minimalistas."

    rec = crud.create_recommendation(db, payload, suggested)
    return rec


@router.get("/history", response_model=List[schemas.Recommendation])
def get_history(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
):
    recs = crud.get_recommendations(db, skip=skip, limit=limit)
    return recs
