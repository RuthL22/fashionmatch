from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class UserBase(BaseModel):
    email: str
    name: Optional[str] = None


class UserCreate(UserBase):
    pass


class User(UserBase):
    id: int

    class Config:
        orm_mode = True


class RecommendationBase(BaseModel):
    description: str
    image_url: Optional[str] = None


class RecommendationCreate(RecommendationBase):
    user_email: Optional[str] = None


class Recommendation(RecommendationBase):
    id: int
    suggested_outfit: str
    created_at: datetime
    user: Optional[User]

    class Config:
        orm_mode = True
