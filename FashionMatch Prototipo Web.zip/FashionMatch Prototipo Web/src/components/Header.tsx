import { Link, useLocation } from 'react-router';
import { Heart, User } from 'lucide-react';

export const Header = () => {
  const location = useLocation();

  return (
    <header className="border-b border-border/50 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between">
        <Link to="/" className="no-underline">
          <h1 className="text-3xl tracking-tight">FashionMatch</h1>
        </Link>
        
        <nav className="flex items-center gap-8">
          <Link 
            to="/" 
            className={`no-underline transition-colors ${
              location.pathname === '/' 
                ? 'text-foreground' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Inicio
          </Link>
          <Link 
            to="/favorites" 
            className={`no-underline transition-colors flex items-center gap-2 ${
              location.pathname === '/favorites' 
                ? 'text-foreground' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Heart className="w-5 h-5" />
            Favoritos
          </Link>
          <Link 
            to="/profile" 
            className={`no-underline transition-colors flex items-center gap-2 ${
              location.pathname === '/profile' 
                ? 'text-foreground' 
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <User className="w-5 h-5" />
            Perfil
          </Link>
        </nav>
      </div>
    </header>
  );
};
