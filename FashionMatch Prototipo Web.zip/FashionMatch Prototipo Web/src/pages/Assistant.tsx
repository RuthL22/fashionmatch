import { useLocation, useNavigate } from 'react-router';
import { Header } from '../components/Header';
import { Sparkles } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Assistant() {
  const location = useLocation();
  const navigate = useNavigate();
  const { image, description } = location.state || { description: 'Casual moderno' };

  const outfits = [
    {
      id: 'casual-1',
      name: 'Casual Chic',
      style: 'Casual',
      image: 'https://images.unsplash.com/photo-1736555142217-916540c7f1b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXN1YWwlMjBvdXRmaXQlMjBmYXNoaW9ufGVufDF8fHx8MTc2NTQ1MTAzOHww&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Look casual perfecto para el día a día. Combina comodidad con estilo.',
      colors: ['#F5E6D3', '#8B7355', '#2C2416'],
      items: [
        { name: 'Blusa de lino', color: 'Beige', image: 'https://images.unsplash.com/photo-1621341103818-01dada8c6ef8' },
        { name: 'Pantalón cargo', color: 'Marrón', image: 'https://images.unsplash.com/photo-1621341103818-01dada8c6ef8' },
        { name: 'Zapatillas blancas', color: 'Blanco', image: 'https://images.unsplash.com/photo-1621341103818-01dada8c6ef8' },
      ],
      accessories: ['Bolso de mano', 'Gafas de sol', 'Reloj minimalista'],
    },
    {
      id: 'elegant-1',
      name: 'Elegante Atemporal',
      style: 'Elegante',
      image: 'https://images.unsplash.com/photo-1761164920960-2d776a18998c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZm9ybWFsJTIwZHJlc3N8ZW58MXx8fHwxNzY1NDI0NTAwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Sofisticación pura. Ideal para eventos formales o cenas elegantes.',
      colors: ['#1A1A1A', '#FFFFFF', '#E8B4B8'],
      items: [
        { name: 'Vestido midi', color: 'Negro', image: 'https://images.unsplash.com/photo-1761164920960-2d776a18998c' },
        { name: 'Blazer estructurado', color: 'Negro', image: 'https://images.unsplash.com/photo-1761164920960-2d776a18998c' },
        { name: 'Tacones clásicos', color: 'Negro', image: 'https://images.unsplash.com/photo-1761164920960-2d776a18998c' },
      ],
      accessories: ['Cartera clutch', 'Collar discreto', 'Aretes de perla'],
    },
    {
      id: 'streetwear-1',
      name: 'Urbano Moderno',
      style: 'Streetwear',
      image: 'https://images.unsplash.com/photo-1628302321078-b08b62f61c92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlZXR3ZWFyJTIwdXJiYW4lMjBvdXRmaXR8ZW58MXx8fHwxNzY1NDUxMDM5fDA&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Estilo urbano contemporáneo. Perfecto para destacar en la ciudad.',
      colors: ['#3A3A3A', '#FFFFFF', '#6B6B6B'],
      items: [
        { name: 'Sudadera oversize', color: 'Gris', image: 'https://images.unsplash.com/photo-1628302321078-b08b62f61c92' },
        { name: 'Jeans wide-leg', color: 'Negro', image: 'https://images.unsplash.com/photo-1628302321078-b08b62f61c92' },
        { name: 'Sneakers chunky', color: 'Blanco/Negro', image: 'https://images.unsplash.com/photo-1628302321078-b08b62f61c92' },
      ],
      accessories: ['Gorra bucket', 'Riñonera', 'Cadena plateada'],
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Header Section */}
        <div className="mb-16 space-y-6">
          <div className="flex items-start gap-8">
            {image && (
              <div className="w-32 h-32 rounded-xl overflow-hidden bg-secondary flex-shrink-0">
                <img src={image} alt="Uploaded" className="w-full h-full object-cover" />
              </div>
            )}
            <div className="flex-1 space-y-3">
              <div className="flex items-center gap-2 text-accent">
                <Sparkles className="w-5 h-5" />
                <span className="uppercase tracking-wider">Análisis completado</span>
              </div>
              <h1 className="text-5xl">Recomendaciones personalizadas</h1>
              <p className="text-xl text-muted-foreground">
                Basado en: <span className="text-foreground italic">"{description}"</span>
              </p>
            </div>
          </div>
        </div>

        {/* Outfits Grid */}
        <div className="space-y-8">
          <h2 className="text-3xl">Outfits seleccionados para ti</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {outfits.map((outfit) => (
              <div 
                key={outfit.id}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all cursor-pointer"
                onClick={() => navigate(`/outfit/${outfit.id}`, { state: { outfit } })}
              >
                <div className="aspect-[3/4] overflow-hidden bg-secondary">
                  <ImageWithFallback
                    src={outfit.image}
                    alt={outfit.name}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                
                <div className="p-6 space-y-4">
                  <div>
                    <div className="text-sm text-muted-foreground uppercase tracking-wider mb-1">
                      {outfit.style}
                    </div>
                    <h3 className="text-2xl">{outfit.name}</h3>
                  </div>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {outfit.description}
                  </p>
                  
                  <div className="space-y-2">
                    <div className="text-sm uppercase tracking-wider text-muted-foreground">
                      Paleta de colores
                    </div>
                    <div className="flex gap-2">
                      {outfit.colors.map((color, idx) => (
                        <div
                          key={idx}
                          className="w-8 h-8 rounded-full border border-border shadow-sm"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>
                  
                  <button className="w-full mt-4 px-6 py-3 border border-border rounded-xl hover:bg-secondary transition-colors">
                    Ver detalles
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Color Combinations */}
        <div className="mt-20 bg-secondary/30 rounded-2xl p-12">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h2 className="text-4xl">Combina bien con estos colores</h2>
            <p className="text-lg text-muted-foreground">
              Basado en tu estilo, estos son los tonos que mejor funcionan
            </p>
            <div className="flex justify-center gap-4 mt-8">
              {['#F5E6D3', '#E8B4B8', '#1A1A1A', '#FFFFFF', '#8B7355', '#6B6B6B'].map((color, idx) => (
                <div key={idx} className="text-center space-y-2">
                  <div
                    className="w-16 h-16 rounded-full border-2 border-white shadow-lg"
                    style={{ backgroundColor: color }}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
