import { useState } from 'react';
import { Header } from '../components/Header';
import { User, Palette, Ruler, Tag } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export default function Profile() {
  const [preferences, setPreferences] = useState({
    styles: ['Casual', 'Elegante'],
    colors: ['#1A1A1A', '#F5E6D3', '#E8B4B8'],
    sizes: {
      top: 'M',
      bottom: '38',
      shoes: '38',
    },
  });

  const styleOptions = ['Casual', 'Elegante', 'Streetwear', 'Formal', 'Bohemio', 'Deportivo'];
  const colorOptions = [
    { name: 'Negro', hex: '#1A1A1A' },
    { name: 'Blanco', hex: '#FFFFFF' },
    { name: 'Beige', hex: '#F5E6D3' },
    { name: 'Rosa pálido', hex: '#E8B4B8' },
    { name: 'Gris', hex: '#6B6B6B' },
    { name: 'Marrón', hex: '#8B7355' },
    { name: 'Azul marino', hex: '#1E3A5F' },
    { name: 'Verde oliva', hex: '#6B7C59' },
  ];

  const toggleStyle = (style: string) => {
    setPreferences(prev => ({
      ...prev,
      styles: prev.styles.includes(style)
        ? prev.styles.filter(s => s !== style)
        : [...prev.styles, style]
    }));
  };

  const toggleColor = (hex: string) => {
    setPreferences(prev => ({
      ...prev,
      colors: prev.colors.includes(hex)
        ? prev.colors.filter(c => c !== hex)
        : [...prev.colors, hex]
    }));
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="max-w-5xl mx-auto px-6 py-12">
        {/* Profile Header */}
        <div className="mb-16">
          <div className="flex items-start gap-8">
            <div className="w-32 h-32 rounded-full bg-secondary flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
              <User className="w-16 h-16 text-muted-foreground" />
            </div>
            <div className="flex-1 space-y-3">
              <h1 className="text-5xl">Mi Perfil</h1>
              <p className="text-xl text-muted-foreground">
                Personaliza tu experiencia de moda
              </p>
              <button className="px-6 py-3 border border-border rounded-xl hover:bg-secondary transition-colors">
                Editar foto de perfil
              </button>
            </div>
          </div>
        </div>

        {/* Preferences Sections */}
        <div className="space-y-12">
          {/* Style Preferences */}
          <section className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <Tag className="w-6 h-6 text-accent" />
              <h2 className="text-3xl">Preferencias de estilo</h2>
            </div>
            <p className="text-muted-foreground">
              Selecciona los estilos que más te gustan para recibir recomendaciones personalizadas
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {styleOptions.map((style) => (
                <button
                  key={style}
                  onClick={() => toggleStyle(style)}
                  className={`px-6 py-4 rounded-xl border-2 transition-all ${
                    preferences.styles.includes(style)
                      ? 'border-accent bg-accent/10 text-foreground'
                      : 'border-border hover:border-accent/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                      preferences.styles.includes(style)
                        ? 'border-accent bg-accent'
                        : 'border-muted-foreground'
                    }`}>
                      {preferences.styles.includes(style) && (
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                    <span>{style}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Color Preferences */}
          <section className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <Palette className="w-6 h-6 text-accent" />
              <h2 className="text-3xl">Colores favoritos</h2>
            </div>
            <p className="text-muted-foreground">
              Elige tu paleta de colores preferida
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {colorOptions.map((color) => (
                <button
                  key={color.hex}
                  onClick={() => toggleColor(color.hex)}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    preferences.colors.includes(color.hex)
                      ? 'border-accent shadow-md'
                      : 'border-border hover:border-accent/50'
                  }`}
                >
                  <div className="space-y-3">
                    <div
                      className="w-full aspect-square rounded-lg border border-border shadow-sm"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-sm block">{color.name}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>

          {/* Size Information */}
          <section className="bg-white rounded-2xl p-8 shadow-sm space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-border">
              <Ruler className="w-6 h-6 text-accent" />
              <h2 className="text-3xl">Tallas registradas</h2>
            </div>
            <p className="text-muted-foreground">
              Guarda tus tallas para recomendaciones más precisas
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <label className="block text-sm uppercase tracking-wider text-muted-foreground">
                  Parte superior
                </label>
                <select
                  value={preferences.sizes.top}
                  onChange={(e) => setPreferences(prev => ({
                    ...prev,
                    sizes: { ...prev.sizes, top: e.target.value }
                  }))}
                  className="w-full px-4 py-3 border border-border rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option>XS</option>
                  <option>S</option>
                  <option>M</option>
                  <option>L</option>
                  <option>XL</option>
                </select>
              </div>
              <div className="space-y-3">
                <label className="block text-sm uppercase tracking-wider text-muted-foreground">
                  Parte inferior
                </label>
                <select
                  value={preferences.sizes.bottom}
                  onChange={(e) => setPreferences(prev => ({
                    ...prev,
                    sizes: { ...prev.sizes, bottom: e.target.value }
                  }))}
                  className="w-full px-4 py-3 border border-border rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option>34</option>
                  <option>36</option>
                  <option>38</option>
                  <option>40</option>
                  <option>42</option>
                  <option>44</option>
                </select>
              </div>
              <div className="space-y-3">
                <label className="block text-sm uppercase tracking-wider text-muted-foreground">
                  Calzado
                </label>
                <select
                  value={preferences.sizes.shoes}
                  onChange={(e) => setPreferences(prev => ({
                    ...prev,
                    sizes: { ...prev.sizes, shoes: e.target.value }
                  }))}
                  className="w-full px-4 py-3 border border-border rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-accent"
                >
                  <option>35</option>
                  <option>36</option>
                  <option>37</option>
                  <option>38</option>
                  <option>39</option>
                  <option>40</option>
                  <option>41</option>
                </select>
              </div>
            </div>
          </section>

          {/* Save Button */}
          <div className="flex justify-end">
            <button className="px-12 py-4 bg-accent text-foreground rounded-xl hover:bg-accent/80 transition-colors shadow-sm">
              Guardar preferencias
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
