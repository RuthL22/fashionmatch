import { useState } from "react";
import { useNavigate } from "react-router";
import { Header } from "../components/Header";
import { Heart, Filter } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { useFavorites } from "../context/FavoritesContext";

export default function Favorites() {
  const navigate = useNavigate();
  const { favorites } = useFavorites();
  const [selectedFilter, setSelectedFilter] =
    useState<string>("Todos");

  const filters = [
    "Todosss",
    "Casual",
    "Elegante",
    "Streetwear",
    "Formal",
    "Noche",
  ];

  const filteredFavorites =
    selectedFilter === "Todos"
      ? favorites
      : favorites.filter(
          (outfit) => outfit.style === selectedFilter,
        );

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Header */}
        <div className="mb-12 space-y-4">
          <div className="flex items-center gap-3">
            <Heart className="w-8 h-8 text-accent fill-current" />
            <h1 className="text-5xl">Mis Favoritos</h1>
          </div>
          <p className="text-xl text-muted-foreground">
            {favorites.length}{" "}
            {favorites.length === 1
              ? "outfit guardado"
              : "outfits guardados"}
          </p>
        </div>

        {/* Filters */}
        <div className="mb-12 flex items-center gap-4 overflow-x-auto pb-4">
          <div className="flex items-center gap-2 text-muted-foreground flex-shrink-0">
            <Filter className="w-5 h-5" />
            <span>Filtrar:</span>
          </div>
          {filters.map((filter) => (
            <button
              key={filter}
              onClick={() => setSelectedFilter(filter)}
              className={`px-6 py-3 rounded-xl transition-all whitespace-nowrap ${
                selectedFilter === filter
                  ? "bg-accent text-foreground shadow-sm"
                  : "bg-white border border-border hover:bg-secondary"
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Favorites Grid */}
        {filteredFavorites.length === 0 ? (
          <div className="text-center py-20 space-y-6">
            <Heart className="w-16 h-16 text-muted-foreground mx-auto opacity-50" />
            <div className="space-y-2">
              <h2 className="text-3xl text-muted-foreground">
                No hay favoritos aún
              </h2>
              <p className="text-lg text-muted-foreground">
                {selectedFilter === "Todos"
                  ? "Comienza a guardar tus outfits favoritos"
                  : `No tienes outfits de estilo ${selectedFilter}`}
              </p>
            </div>
            <button
              onClick={() => navigate("/")}
              className="px-8 py-4 bg-accent text-foreground rounded-xl hover:bg-accent/80 transition-colors"
            >
              Descubrir outfits
            </button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredFavorites.map((outfit) => (
              <div
                key={outfit.id}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all cursor-pointer"
                onClick={() =>
                  navigate(`/outfit/${outfit.id}`, {
                    state: { outfit },
                  })
                }
              >
                <div className="aspect-[3/4] overflow-hidden bg-secondary relative">
                  <ImageWithFallback
                    src={outfit.image}
                    alt={outfit.name}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute top-4 right-4">
                    <Heart className="w-6 h-6 text-white fill-current drop-shadow-lg" />
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div>
                    <div className="text-sm text-muted-foreground uppercase tracking-wider mb-1">
                      {outfit.style}
                    </div>
                    <h3 className="text-2xl">{outfit.name}</h3>
                  </div>

                  <p className="text-muted-foreground leading-relaxed line-clamp-2">
                    {outfit.description}
                  </p>

                  <div className="space-y-2">
                    <div className="text-sm uppercase tracking-wider text-muted-foreground">
                      Paleta de colores
                    </div>
                    <div className="flex gap-2">
                      {outfit.colors.map((color, idx) => (
                        <div
                          key={idx}
                          className="w-8 h-8 rounded-full border border-border shadow-sm"
                          style={{ backgroundColor: color }}
                        />
                      ))}
                    </div>
                  </div>

                  <button className="w-full mt-4 px-6 py-3 border border-border rounded-xl hover:bg-secondary transition-colors">
                    Ver detalles
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}