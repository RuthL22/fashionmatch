import { useLocation, useNavigate } from 'react-router';
import { Header } from '../components/Header';
import { Heart, ArrowLeft, ShoppingBag } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { useFavorites } from '../context/FavoritesContext';
import { toast } from 'sonner@2.0.3';
import { Toaster } from '../components/ui/sonner';

export default function OutfitDetail() {
  const location = useLocation();
  const navigate = useNavigate();
  const { outfit } = location.state || {};
  const { addFavorite, removeFavorite, isFavorite } = useFavorites();

  if (!outfit) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-6 py-20 text-center">
          <p className="text-muted-foreground">No se encontró información del outfit.</p>
          <button 
            onClick={() => navigate('/')}
            className="mt-4 px-6 py-3 bg-accent rounded-xl"
          >
            Volver al inicio
          </button>
        </div>
      </div>
    );
  }

  const isInFavorites = isFavorite(outfit.id);

  const handleToggleFavorite = () => {
    if (isInFavorites) {
      removeFavorite(outfit.id);
      toast.success('Eliminado de favoritos');
    } else {
      addFavorite(outfit);
      toast.success('Guardado en favoritos');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Toaster />
      
      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
        >
          <ArrowLeft className="w-5 h-5" />
          Volver
        </button>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Image Section */}
          <div className="space-y-6">
            <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-secondary shadow-xl">
              <ImageWithFallback
                src={outfit.image}
                alt={outfit.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Color Palette */}
            <div className="bg-white rounded-2xl p-8 space-y-4 shadow-sm">
              <h3 className="text-xl">Paleta de colores</h3>
              <div className="flex gap-3">
                {outfit.colors.map((color: string, idx: number) => (
                  <div key={idx} className="flex-1 text-center space-y-2">
                    <div
                      className="w-full aspect-square rounded-xl border border-border shadow-sm"
                      style={{ backgroundColor: color }}
                    />
                    <div className="text-xs text-muted-foreground uppercase tracking-wider">
                      {color}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Details Section */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground uppercase tracking-wider">
                {outfit.style}
              </div>
              <h1 className="text-5xl">{outfit.name}</h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                {outfit.description}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4">
              <button
                onClick={handleToggleFavorite}
                className={`flex-1 px-6 py-4 rounded-xl transition-all flex items-center justify-center gap-2 ${
                  isInFavorites 
                    ? 'bg-accent text-foreground' 
                    : 'border border-border hover:bg-secondary'
                }`}
              >
                <Heart className={`w-5 h-5 ${isInFavorites ? 'fill-current' : ''}`} />
                {isInFavorites ? 'En favoritos' : 'Guardar en favoritos'}
              </button>
              <button className="px-6 py-4 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors flex items-center gap-2">
                <ShoppingBag className="w-5 h-5" />
                Comprar similar
              </button>
            </div>

            {/* Items List */}
            <div className="space-y-4">
              <h3 className="text-2xl">Prendas incluidas</h3>
              <div className="space-y-4">
                {outfit.items.map((item: any, idx: number) => (
                  <div key={idx} className="bg-white rounded-xl p-6 shadow-sm flex items-center gap-6">
                    <div className="w-20 h-20 rounded-lg bg-secondary flex-shrink-0" />
                    <div className="flex-1">
                      <h4 className="mb-1">{item.name}</h4>
                      <p className="text-muted-foreground">Color: {item.color}</p>
                    </div>
                    <button className="px-4 py-2 border border-border rounded-lg hover:bg-secondary transition-colors text-sm">
                      Ver similar
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Accessories */}
            <div className="space-y-4">
              <h3 className="text-2xl">Accesorios recomendados</h3>
              <div className="grid grid-cols-3 gap-4">
                {outfit.accessories.map((accessory: string, idx: number) => (
                  <div key={idx} className="bg-white rounded-xl p-4 shadow-sm text-center space-y-3">
                    <div className="aspect-square rounded-lg bg-secondary" />
                    <p className="text-sm">{accessory}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Complementary Colors */}
            <div className="bg-secondary/30 rounded-2xl p-8 space-y-4">
              <h3 className="text-xl">Combina bien con estos colores</h3>
              <div className="flex gap-3">
                {['#F5E6D3', '#8B7355', '#FFFFFF', '#E8B4B8', '#6B6B6B'].map((color, idx) => (
                  <div
                    key={idx}
                    className="w-12 h-12 rounded-full border-2 border-white shadow-md"
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
