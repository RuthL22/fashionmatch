import { useState } from "react";
import { useNavigate } from "react-router";
import { Header } from "../components/Header";
import { Upload, Sparkles } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export default function Home() {
  const navigate = useNavigate();
  const [description, setDescription] = useState("");
  const [selectedImage, setSelectedImage] = useState<
    string | null
  >(null);

  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGetRecommendations = () => {
    navigate("/assistant", {
      state: {
        image: selectedImage,
        description: description || "Outfit casual y moderno",
      },
    });
  };

  const styleCategories = [
    {
      name: "Casual",
      image:
        "https://images.unsplash.com/photo-1736555142217-916540c7f1b7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXN1YWwlMjBvdXRmaXQlMjBmYXNoaW9ufGVufDF8fHx8MTc2NTQ1MTAzOHww&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Formal",
      image:
        "https://images.unsplash.com/photo-1760080839053-a828d4c30500?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGZvcm1hbCUyMGF0dGlyZXxlbnwxfHx8fDE3NjU0NTEwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Noche",
      image:
        "https://images.unsplash.com/photo-1633124907612-e3631619409a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWdodCUyMHBhcnR5JTIwZHJlc3N8ZW58MXx8fHwxNzY1NDUxMDQwfDA&ixlib=rb-4.1.0&q=80&w=1080",
    },
    {
      name: "Playa",
      image:
        "https://images.unsplash.com/photo-1718839932371-7adaf5edc96a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWFjaCUyMHN1bW1lciUyMG91dGZpdHxlbnwxfHx8fDE3NjU0NTEwMzl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-6xl">
                Tu asistente personal de moda
              </h1>
              <p className="text-xl text-muted-foreground max-w-lg">
                Descubre outfits personalizados creados
                especialmente para ti. Sube una foto o describe
                tu estilo y deja que nuestra IA haga el resto.
              </p>
            </div>

            {/* Upload Section */}
            <div className="space-y-6 bg-secondary/30 p-8 rounded-2xl">
              <div>
                <label
                  htmlFor="image-upload"
                  className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed border-border rounded-xl cursor-pointer bg-white hover:bg-secondary/50 transition-colors"
                >
                  {selectedImage ? (
                    <div className="relative w-full h-full">
                      <img
                        src={selectedImage}
                        alt="Preview"
                        className="w-full h-full object-cover rounded-xl"
                      />
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center rounded-xl opacity-0 hover:opacity-100 transition-opacity">
                        <Upload className="w-8 h-8 text-white" />
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-3">
                      <Upload className="w-10 h-10 text-muted-foreground" />
                      <span className="text-muted-foreground">
                        Subir foto de prenda o outfit
                      </span>
                    </div>
                  )}
                  <input
                    id="image-upload"
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </label>
              </div>

              <div className="relative">
                <input
                  type="text"
                  placeholder="Describeee el estilo que buscás..."
                  value={description}
                  onChange={(e) =>
                    setDescription(e.target.value)
                  }
                  className="w-full px-6 py-4 rounded-xl border border-border bg-white focus:outline-none focus:ring-2 focus:ring-accent"
                />
              </div>

              <button
                onClick={handleGetRecommendations}
                className="w-full bg-accent hover:bg-accent/80 text-foreground px-8 py-4 rounded-xl transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md"
              >
                <Sparkles className="w-5 h-5" />
                Recomendar outfit
              </button>
            </div>
          </div>

          <div className="relative aspect-[3/4] rounded-2xl overflow-hidden shadow-2xl">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1621341103818-01dada8c6ef8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwZmFzaGlvbiUyMG1vZGVsJTIwbmV1dHJhbHxlbnwxfHx8fDE3NjU0NTEwMzh8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Fashion Model"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>

      {/* Style Categories */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="space-y-12">
          <div className="text-center space-y-4">
            <h2 className="text-5xl">Explora por estilo</h2>
            <p className="text-lg text-muted-foreground">
              Descubre looks perfectos para cada ocasión
            </p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {styleCategories.map((category) => (
              <button
                key={category.name}
                onClick={() =>
                  navigate("/assistant", {
                    state: { description: category.name },
                  })
                }
                className="group relative aspect-[3/4] rounded-xl overflow-hidden bg-secondary cursor-pointer"
              >
                <ImageWithFallback
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-white text-2xl">
                    {category.name}
                  </h3>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}