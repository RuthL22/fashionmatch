import { createContext, useContext, useState, ReactNode } from 'react';

export interface Outfit {
  id: string;
  name: string;
  style: string;
  image: string;
  description: string;
  colors: string[];
  items: {
    name: string;
    color: string;
    image: string;
  }[];
  accessories: string[];
}

interface FavoritesContextType {
  favorites: Outfit[];
  addFavorite: (outfit: Outfit) => void;
  removeFavorite: (id: string) => void;
  isFavorite: (id: string) => boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const FavoritesProvider = ({ children }: { children: ReactNode }) => {
  const [favorites, setFavorites] = useState<Outfit[]>([]);

  const addFavorite = (outfit: Outfit) => {
    setFavorites((prev) => {
      if (prev.find((f) => f.id === outfit.id)) {
        return prev;
      }
      return [...prev, outfit];
    });
  };

  const removeFavorite = (id: string) => {
    setFavorites((prev) => prev.filter((f) => f.id !== id));
  };

  const isFavorite = (id: string) => {
    return favorites.some((f) => f.id === id);
  };

  return (
    <FavoritesContext.Provider value={{ favorites, addFavorite, removeFavorite, isFavorite }}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (!context) {
    throw new Error('useFavorites must be used within a FavoritesProvider');
  }
  return context;
};
