import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import Assistant from "./pages/Assistant";
import OutfitDetail from "./pages/OutfitDetail";
import Favorites from "./pages/Favorites";
import Profile from "./pages/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/assistant",
    Component: Assistant,
  },
  {
    path: "/outfit/:id",
    Component: OutfitDetail,
  },
  {
    path: "/favorites",
    Component: Favorites,
  },
  {
    path: "/profile",
    Component: Profile,
  },
]);
